## snake-game
A simple snake game implemented in java for practice.

### Behavior (draft)
- *Valid keys* : **w, a, s, d** 
- Game ends when :
    - Invalid input is entered
    - Snake bites it's own body
    - Snake leaves the boundary
    - Fetching new food coordinates becomes an expensive operation
