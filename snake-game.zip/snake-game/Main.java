// Game components
import components.*;

// Main class
public class Main {
    public static void main(String[] args) {

        // Initalize board
        Board board = new Board();
        // Start Game
        board.startGame();

        return;
    }
};
